### Hexlet tests and linter status:
[![Actions Status](https://github.com/Vladimir3110/python-project-49/actions/workflows/hexlet-check.yml/badge.svg)](https://github.com/Vladimir3110/python-project-49/actions)

[![Test Coverage](https://api.codeclimate.com/v1/badges/9b8c24ec20c341173598/test_coverage)](https://codeclimate.com/github/Vladimir3110/python-project-49/test_coverage)